function clicked() {
  document.getElementById("count").innerHTML = (document.getElementById("count").innerHTML) ;
    return /* () */0;
  }
  Element.setInnerHTML(Document.getElementById("count"),x);

  //let b = int_of_string (Element.getInnerHTML(Document.getElementById ("count")));
  //let c = b+1;

  Element.setInnerHTML(Document.getElementById("count"));